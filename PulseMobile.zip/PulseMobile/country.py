import pandas as pd

# Chemins des fichiers CSV (mettez à jour avec les chemins réels de vos fichiers)
path_filtered_phones = '/Users/simonjouanique/Downloads/PulseMobile/Filtered_Mobile_Phones_Post_2019.csv'
path_brands_country = '/Users/simonjouanique/Downloads/PulseMobile/Mobile Phone Brands by Country.csv'

# Charger les fichiers CSV
filtered_phones = pd.read_csv(path_filtered_phones)
brands_country = pd.read_csv(path_brands_country)

# Affichage des colonnes pour vérifier les noms
print("Colonnes pour les téléphones filtrés :", filtered_phones.columns)
print("Colonnes pour les marques par pays :", brands_country.columns)

# Renommer la colonne 'Brand' en 'manufacturer' pour pouvoir faire la fusion
brands_country.rename(columns={'Brand': 'manufacturer'}, inplace=True)

# Fusionner les deux fichiers sur la colonne 'manufacturer' et ajouter la colonne 'Country'
merged_data = pd.merge(filtered_phones, brands_country[['manufacturer', 'Country']], on='manufacturer', how='left')

# Sauvegarder les données fusionnées dans un nouveau fichier CSV
output_path = '/Users/simonjouanique/Downloads/PulseMobile/Output_Merged_Data.csv'  # Modifiez avec le chemin où vous voulez enregistrer
merged_data.to_csv(output_path, index=False)

print("Fusion terminée et fichier sauvegardé à l'emplacement :", output_path)
