import pandas as pd
from sklearn.neighbors import NearestNeighbors
import numpy as np

# Charger les données du fichier CSV
file_path = '/Users/simonjouanique/Downloads/PulseMobile/Updated_Smartphone_Data_with_Individual_iPhone_12_Models 1.csv'  # Remplacez par le chemin de votre fichier
smartphone_data = pd.read_csv(file_path, delimiter=';')

# Prétraitement des données (convertir en numérique)
def preprocess_data(df):
    # Conversion des colonnes de stockage, RAM, batterie en numérique
    df['Storage_min'] = df['Storage'].str.extract('(\d+)').astype(float)
    df['RAM_min'] = df['RAM'].str.extract('(\d+)').astype(float)
    df['Battery_min'] = df['Battery'].str.extract('(\d+)').astype(float)

    # Remplacer les valeurs manquantes par une valeur standard
    df['RAM_min'].fillna(df['RAM_min'].mean(), inplace=True)
    df['Battery_min'].fillna(df['Battery_min'].mean(), inplace=True)

    return df

# Préparer les données
smartphone_data = preprocess_data(smartphone_data)

# Fonction pour poser des questions et recommander un smartphone
def recommend_smartphone(df):
    print("Bienvenue au système de recommandation de téléphones ! Répondez aux questions suivantes pour obtenir des suggestions.")

    # Entrée utilisateur pour les préférences
    preferred_storage = float(input("Capacité de stockage minimum souhaitée (en GB) ? "))
    preferred_ram = float(input("Quantité de RAM minimum souhaitée (en GB) ? "))
    preferred_battery = float(input("Capacité de batterie minimum souhaitée (en mAh) ? "))

    # Créer un tableau des préférences de l'utilisateur
    user_preferences = np.array([[preferred_storage, preferred_ram, preferred_battery]])

    # Filtrer les données à utiliser pour la recommandation
    X = df[['Storage_min', 'RAM_min', 'Battery_min']].values

    # Appliquer l'algorithme KNN pour trouver les 3 téléphones les plus proches
    knn = NearestNeighbors(n_neighbors=3, algorithm='auto')
    knn.fit(X)
    distances, indices = knn.kneighbors(user_preferences)

    # Afficher les 3 meilleurs résultats (le plus proche + 2 alternatives)
    print("\nLe smartphone recommandé le plus proche de vos préférences est :\n")
    print(df.iloc[indices[0][0]][['manufacturer', 'model', 'Storage', 'RAM', 'Battery', 'launch_price_usd']])

    print("\nDeux alternatives à considérer :\n")
    print(df.iloc[indices[0][1]][['manufacturer', 'model', 'Storage', 'RAM', 'Battery', 'launch_price_usd']])
    print("\nEt aussi :\n")
    print(df.iloc[indices[0][2]][['manufacturer', 'model', 'Storage', 'RAM', 'Battery', 'launch_price_usd']])

# Exécuter la fonction de recommandation
recommend_smartphone(smartphone_data)
