import pandas as pd
from sklearn.neighbors import NearestNeighbors
import numpy as np
from flask import Flask, render_template, request

# Charger les données du fichier CSV
file_path = '/Users/simonjouanique/Downloads/PulseMobile/Updated_Smartphone_Data_with_Individual_iPhone_12_Models 1.csv'  # Remplacez par le chemin de votre fichier
smartphone_data = pd.read_csv(file_path, delimiter=';')

# Prétraitement des données (convertir en numérique)
def preprocess_data(df):
    # Extraire les informations numériques des colonnes pertinentes
    df['Storage_min'] = df['Storage'].str.extract('(\d+)').astype(float)
    df['RAM_min'] = df['RAM'].str.extract('(\d+)').astype(float)
    df['Battery_min'] = df['Battery'].str.extract('(\d+)').astype(float)
    
    # Extraction des prix et conversion en float
    df['Price'] = pd.to_numeric(df['launch_price_usd'].str.replace(r'[^\d.]', '', regex=True), errors='coerce')

    # Remplir les valeurs manquantes par la moyenne pour éviter les erreurs
    df['RAM_min'].fillna(df['RAM_min'].mean(), inplace=True)
    df['Battery_min'].fillna(df['Battery_min'].mean(), inplace=True)
    df['Price'].fillna(df['Price'].mean(), inplace=True)  # Remplacer les prix manquants par la moyenne
    return df

# Préparer les données
smartphone_data = preprocess_data(smartphone_data)

# Initialiser l'application Flask
app = Flask(__name__)

# Page d'accueil pour entrer les critères
@app.route('/')
def index():
    return render_template('index.html')

# Page pour afficher les recommandations
@app.route('/recommender', methods=['POST'])
def recommender():
    # Récupérer les valeurs du formulaire soumis par l'utilisateur
    preferred_storage = float(request.form['storage'])
    preferred_ram = float(request.form['ram'])
    preferred_battery = float(request.form['battery'])
    budget = float(request.form['budget'])

    # Créer un tableau des préférences de l'utilisateur
    user_preferences = np.array([[preferred_storage, preferred_ram, preferred_battery]])

    # Filtrer les téléphones selon le budget
    df_filtered = smartphone_data[smartphone_data['Price'] <= budget]

    # Vérifier s'il y a des téléphones correspondant au budget
    if df_filtered.empty:
        return "Désolé, aucun smartphone ne correspond à votre budget."

    # Appliquer l'algorithme KNN pour trouver les téléphones les plus proches des critères
    X = df_filtered[['Storage_min', 'RAM_min', 'Battery_min']].values
    knn = NearestNeighbors(n_neighbors=3, algorithm='auto')
    knn.fit(X)
    distances, indices = knn.kneighbors(user_preferences)

    # Récupérer les 3 téléphones les plus proches
    best_match = df_filtered.iloc[indices[0][0]]
    alternative_1 = df_filtered.iloc[indices[0][1]]
    alternative_2 = df_filtered.iloc[indices[0][2]]

    # Envoyer les résultats à la page HTML
    return render_template('results.html', 
                           best_match=best_match, 
                           alternative_1=alternative_1, 
                           alternative_2=alternative_2)

# Lancer l'application Flask
if __name__ == '__main__':
    app.run(debug=True)
