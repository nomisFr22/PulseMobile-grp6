import pandas as pd

# Load the data from the CSV file
file_path = '/Users/simonjouanique/Downloads/PulseMobile/Mobile Phones Best Sellers.csv'
data = pd.read_csv(file_path)

# Filter the data to include only models released after 2019
filtered_data = data[data['year'] > 2018]

# Save the filtered data to a new CSV file
filtered_data.to_csv('Filtered_Mobile_Phones_Post_2019.csv', index=False)
